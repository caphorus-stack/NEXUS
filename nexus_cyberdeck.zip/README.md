# NEXUS Cyberdeck -- Horus-native build

Runs entirely in Horus's Alpine Linux terminal on your Redmi Note 8 Pro.
No Android Studio, no custom APK, no root.

## Why there's no custom Android app here

Horus is a PRoot userspace environment -- no root, no kernel-level
device access. Android's Wi-Fi/BLE scanning APIs (`WifiManager`,
`BluetoothLeScanner`) are Java/Kotlin framework APIs that only exist
inside a real Android app process with granted runtime permissions.
Alpine Linux under PRoot has no path to them -- not a missing package,
a structural boundary.

So instead of a custom-built, unsigned, hard-to-maintain Kotlin app,
this build uses **WiGLE WiFi Wardriving** (F-Droid, `net.wigle.wigleandroid`)
as the Wi-Fi/BLE scanning front end, and exports its CSV into NEXUS's
schema. This is exactly the "JSON/file handoff" integration strategy
the original spec called for (sec. 5) -- just using a proven open-source
scanner instead of writing + signing a new APK with no Android Studio
available.

## What's out of scope (unchanged from spec, enforced in code)

- No bypassing Android/MIUI permissions, no raw spectrum analysis, no
  breaking encryption, no scanning networks you haven't authorised.
- LAN Watch refuses to run without `--confirm` and refuses public IP
  ranges outright (see `nexus/lan_watch.py`).
- A host that doesn't respond is never reported as "offline" -- it's
  just not reported. A BLE device that never appears is never reported
  as "not present."
- Nothing leaves the phone. Everything lives in a local SQLite file
  under `~/.nexus/nexus.db`.

## 1. Set up Horus

Inside the Horus terminal:

```sh
apk add python3 py3-pip py3-sqlite3
pip install --break-system-packages rich
```

`rich` is optional -- the dashboard auto-detects it and falls back to
plain ANSI colour if it's missing, so a flaky `pip install` won't brick
the tool.

## 2. Get these files onto the phone

Pick whichever of these actually works for you -- I don't know your
exact Horus version's import UI, so don't trust a single path blindly:

- **Horus's own file import**, if its UI offers one (check its menu --
  the F-Droid listing only confirms a *read-only browser*, not
  necessarily an import button, so verify on-device).
- **Android's Share sheet**: if you can get this folder zipped and
  shared from another app, see if "Horus" appears as a share target.
- **USB + the `horus` CLI** on your PC (the pairing tool mentioned on
  F-Droid) -- check `horus --help` on your machine for its file-copy
  command.
- **Universal fallback (always works):** on your PC, in this folder, run:
  ```sh
  python3 -m http.server 8000
  ```
  Then in Horus (same Wi-Fi):
  ```sh
  curl -o nexus.zip http://<your-pc-ip>:8000/nexus_cyberdeck.zip
  unzip nexus.zip && cd nexus_cyberdeck
  ```

Verify afterwards with `python3 -m nexus.cli dashboard overview` -- it
should print an empty dashboard with no errors.

## 3. Get a Wi-Fi/BLE scan

1. Install **WiGLE WiFi Wardriving** from F-Droid.
2. Run it, let it scan for a bit (Wi-Fi APs and BLE devices both log
   automatically once scanning is on).
3. In WiGLE, find its export option (CSV) and export a run.
4. Get that `.csv` onto the phone's shared storage, then into Horus's
   filesystem using whichever transfer method worked in step 2.

## 4. Use it

```sh
# import a WiGLE export
python3 -m nexus.cli import wigle /path/to/export.csv --session myfirstscan

# dashboard views
python3 -m nexus.cli dashboard overview
python3 -m nexus.cli dashboard wifi
python3 -m nexus.cli dashboard bluetooth
python3 -m nexus.cli dashboard lan
python3 -m nexus.cli dashboard history

# LAN watch -- only on a subnet you own/are authorised to probe
python3 -m nexus.cli lan-watch --subnet 192.168.1.0/24 --confirm

# generate a report (written to ~/nexus_reports/)
python3 -m nexus.cli report

# manage history
python3 -m nexus.cli history list
python3 -m nexus.cli history delete --session myfirstscan
python3 -m nexus.cli history delete --all
```

## Project layout

```
nexus/
  schema.py           versioned observation schema + validation
  store.py            local-only SQLite store (sessions/observations/events)
  adapters/
    wigle_csv.py       WiGLE CSV -> NEXUS schema (drops GPS fields on purpose)
  lan_watch.py         bounded, opt-in TCP-connect LAN probing
  dashboard.py         terminal UI (rich, with plain-ANSI fallback)
  reports.py           markdown report generator
  cli.py               `python3 -m nexus.cli ...` entry point
```

## What's genuinely tested vs. what needs on-device verification

Tested in this build: schema validation (rejects malformed envelopes
whole, no partial import), WiGLE CSV parsing, SQLite store, LAN Watch
authorisation/range guards, dashboard rendering (both rich and plain
modes), report generation, history delete.

**Not yet tested on your actual phone:** WiGLE's exact export menu
location, Horus's exact file-import mechanism, and `pip install` under
Horus's specific Alpine/PRoot build. Per the spec's own acceptance
criteria (sec. 11): don't claim full compatibility until you've run it
on the real device. Phase 0 in the original delivery plan -- record
your actual Android/MIUI version and confirm `pip`/WiGLE both behave as
expected -- is still worth doing first.

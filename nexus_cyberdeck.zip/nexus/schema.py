"""
NEXUS observation schema (v1.0)

Three observation types only. Each is a *real* thing a sensor reported,
never a claim about a device, a person, or a location beyond what the
source data actually contains.

  wifi_ap            -- an access point seen in a Wi-Fi scan
  ble_advertisement  -- a BLE advertisement seen in a Bluetooth scan
  lan_host           -- a host that responded to a bounded, authorised
                         LAN probe (never "is online", only "responded")

Envelope wraps a batch of observations from one import/collection event.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field, asdict
from typing import Any, Literal, Optional

SCHEMA_VERSION = "1.0"

ObservationType = Literal["wifi_ap", "ble_advertisement", "lan_host"]


def now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


class SchemaError(ValueError):
    """Raised when imported data doesn't match the NEXUS schema."""


@dataclass
class WifiAP:
    bssid: str
    ssid: Optional[str] = None
    channel: Optional[int] = None
    frequency_mhz: Optional[int] = None
    rssi_dbm: Optional[int] = None
    security: Optional[str] = None
    first_seen: Optional[str] = None
    last_seen: str = field(default_factory=now_iso)
    source: str = "unknown"
    type: str = field(default="wifi_ap", init=False)


@dataclass
class BLEAdvertisement:
    address: str
    local_name: Optional[str] = None
    address_type: str = "unknown"  # public | random | unknown
    rssi_dbm: Optional[int] = None
    last_seen: str = field(default_factory=now_iso)
    source: str = "unknown"
    type: str = field(default="ble_advertisement", init=False)


@dataclass
class LANHost:
    ip: str
    responded: bool
    probe_type: str  # "tcp_port"
    port: Optional[int] = None
    rtt_ms: Optional[float] = None
    observed_at: str = field(default_factory=now_iso)
    source: str = "lan_watch"
    type: str = field(default="lan_host", init=False)


@dataclass
class Event:
    event_type: str  # ap_observed | ble_observed | host_responded | scan_throttled | permission_denied | import | report
    timestamp: str = field(default_factory=now_iso)
    detail: str = ""


_REQUIRED_FIELDS = {
    "wifi_ap": {"bssid"},
    "ble_advertisement": {"address"},
    "lan_host": {"ip", "responded", "probe_type"},
}

_ALLOWED_TYPES = set(_REQUIRED_FIELDS)


def validate_observation(obs: dict[str, Any]) -> None:
    """Raise SchemaError if `obs` isn't a well-formed observation dict."""
    otype = obs.get("type")
    if otype not in _ALLOWED_TYPES:
        raise SchemaError(f"unknown or missing observation type: {otype!r}")
    missing = _REQUIRED_FIELDS[otype] - obs.keys()
    if missing:
        raise SchemaError(f"{otype} observation missing required field(s): {missing}")


def validate_envelope(envelope: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Validate a NEXUS import envelope. Returns the list of observations
    on success. Raises SchemaError on any structural or version problem.
    Malformed envelopes are rejected whole -- no partial silent import.
    """
    if not isinstance(envelope, dict):
        raise SchemaError("envelope must be a JSON object")

    version = envelope.get("schema_version")
    if version != SCHEMA_VERSION:
        raise SchemaError(
            f"unsupported schema_version {version!r} (expected {SCHEMA_VERSION!r})"
        )

    if "source" not in envelope:
        raise SchemaError("envelope missing required field: source")

    observations = envelope.get("observations")
    if not isinstance(observations, list):
        raise SchemaError("envelope.observations must be a list")

    for i, obs in enumerate(observations):
        try:
            validate_observation(obs)
        except SchemaError as e:
            raise SchemaError(f"observation[{i}]: {e}") from e

    return observations


def make_envelope(source: str, observations: list[dict[str, Any]],
                   collection_time: Optional[str] = None,
                   notes: str = "") -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "source": source,
        "collection_time": collection_time or now_iso(),
        "notes": notes,
        "observations": observations,
    }


def to_dict(obj) -> dict:
    return asdict(obj)

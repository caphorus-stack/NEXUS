#!/usr/bin/env python3
"""
NEXUS Cyberdeck CLI -- runs entirely inside Horus (Alpine/PRoot).

    nexus import wigle <csv-file> [--session NAME]
    nexus dashboard [overview|wifi|bluetooth|lan|history|settings]
    nexus lan-watch --subnet 192.168.1.0/24 --confirm [--session NAME]
    nexus report [--session NAME]
    nexus history list
    nexus history delete --session NAME
    nexus history delete --all
"""

from __future__ import annotations

import argparse
import sys
import uuid

from .schema import validate_envelope, SchemaError, Event
from .adapters.wigle_csv import parse_wigle_csv
from .store import Store
from . import dashboard, reports, lan_watch


def _new_session_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


def cmd_import(args: argparse.Namespace) -> int:
    store = Store()
    if args.format == "wigle":
        try:
            envelope = parse_wigle_csv(args.file)
        except SchemaError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 1
    else:
        print(f"ERROR: unknown import format {args.format!r}", file=sys.stderr)
        return 1

    try:
        observations = validate_envelope(envelope)
    except SchemaError as e:
        print(f"ERROR: envelope failed validation: {e}", file=sys.stderr)
        return 1

    session_id = args.session or _new_session_id(args.format)
    store.create_session(session_id, source=envelope["source"], notes=envelope.get("notes", ""))
    n = store.save_observations(session_id, observations)
    store.log_event(Event(event_type="import", detail=f"{n} observation(s) from {args.file}"),
                     session_id=session_id)
    print(f"Imported {n} observation(s) into session '{session_id}'.")
    print(envelope.get("notes", ""))
    return 0


def cmd_dashboard(args: argparse.Namespace) -> int:
    store = Store()
    view = args.view
    if view == "overview":
        dashboard.overview(store, args.session)
    elif view == "wifi":
        dashboard.wifi_field(store, args.session)
    elif view == "bluetooth":
        dashboard.bluetooth_field(store, args.session)
    elif view == "lan":
        dashboard.lan_watch_view(store, args.session)
    elif view == "history":
        dashboard.history_view(store)
    elif view == "settings":
        dashboard.settings_view(store)
    else:
        print(f"ERROR: unknown view {view!r}", file=sys.stderr)
        return 1
    return 0


def cmd_lan_watch(args: argparse.Namespace) -> int:
    if not args.confirm:
        print("Refusing to scan: pass --confirm to authorise probing this subnet.\n"
              "Only run this against a network you own or have explicit permission to test.",
              file=sys.stderr)
        return 1

    store = Store()
    session_id = args.session or _new_session_id("lan")
    store.create_session(session_id, source="lan_watch", notes=f"subnet={args.subnet}")
    print(f"Probing {args.subnet} (TCP connect, bounded, authorised by you)...")

    try:
        observations = list(lan_watch.scan_subnet(args.subnet, authorized=True))
    except lan_watch.LANWatchError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    n = store.save_observations(session_id, observations)
    store.log_event(Event(event_type="host_responded", detail=f"{n} host(s) responded"),
                     session_id=session_id)
    print(f"{n} host(s) responded to probe. Session: {session_id}")
    print("Reminder: 'responded to probe' only -- not a claim about internet access or ownership.")
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    store = Store()
    path = reports.generate_report(store, session_id=args.session)
    store.log_event(Event(event_type="report", detail=f"wrote {path}"), session_id=args.session)
    print(f"Report written to: {path}")
    return 0


def cmd_history(args: argparse.Namespace) -> int:
    store = Store()
    if args.action == "list":
        dashboard.history_view(store)
    elif args.action == "delete":
        if args.all:
            store.delete_all()
            print("All sessions, observations and events deleted.")
        elif args.session:
            store.delete_session(args.session)
            print(f"Session '{args.session}' deleted.")
        else:
            print("ERROR: delete requires --session NAME or --all", file=sys.stderr)
            return 1
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="nexus", description="NEXUS Cyberdeck -- Horus-native")
    sub = p.add_subparsers(dest="command", required=True)

    p_import = sub.add_parser("import", help="import observations from an exported file")
    p_import.add_argument("format", choices=["wigle"], help="source format")
    p_import.add_argument("file", help="path to exported file (e.g. WiGLE CSV)")
    p_import.add_argument("--session", help="session id to import into (default: auto-generated)")
    p_import.set_defaults(func=cmd_import)

    p_dash = sub.add_parser("dashboard", help="render a dashboard view")
    p_dash.add_argument("view", nargs="?", default="overview",
                         choices=["overview", "wifi", "bluetooth", "lan", "history", "settings"])
    p_dash.add_argument("--session", help="filter to one session id")
    p_dash.set_defaults(func=cmd_dashboard)

    p_lan = sub.add_parser("lan-watch", help="bounded, opt-in LAN reachability probe")
    p_lan.add_argument("--subnet", required=True, help="CIDR, e.g. 192.168.1.0/24 (private ranges only)")
    p_lan.add_argument("--confirm", action="store_true", help="required: authorise this scan")
    p_lan.add_argument("--session", help="session id to log results under")
    p_lan.set_defaults(func=cmd_lan_watch)

    p_report = sub.add_parser("report", help="generate a markdown report")
    p_report.add_argument("--session", help="filter to one session id")
    p_report.set_defaults(func=cmd_report)

    p_hist = sub.add_parser("history", help="list or delete local sessions")
    p_hist.add_argument("action", choices=["list", "delete"])
    p_hist.add_argument("--session", help="session id (for delete)")
    p_hist.add_argument("--all", action="store_true", help="delete everything (for delete)")
    p_hist.set_defaults(func=cmd_history)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

"""
Adapter: WiGLE WiFi Wardriving CSV export -> NEXUS observation envelope.

This is NEXUS's "Component A" in practice -- WiGLE (F-Droid:
net.wigle.wigleandroid) already owns the Android Wi-Fi/BLE scanning APIs
and permission flow, so NEXUS doesn't need its own compiled Android app
to get real observations. This file is the JSON-handoff boundary the
spec's "Initial integration strategy" asked for.

WiGLE CSV format (as exported by the app):

    WigleWifi-1.4,appRelease=...,model=...,release=...,device=...,...
    MAC,SSID,AuthMode,FirstSeen,Channel,Frequency,RSSI,CurrentLatitude,
    CurrentLongitude,AltitudeMeters,AccuracyMeters,Type

Row 1 is a metadata line (starts with "WigleWifi"), row 2 is the real
header, remaining rows are one sighting each. `Type` is WIFI or BLE
(occasionally GSM/CDMA/LTE for cell towers, which we ignore here --
out of scope for NEXUS).

DELIBERATE DESIGN CHOICE: CurrentLatitude/CurrentLongitude/Altitude/
Accuracy columns are read but never stored or surfaced. The spec is
explicit that NEXUS does not identify exact physical locations --
geotagged wardriving data would violate that promise, so we drop it
here at the ingestion boundary rather than trusting every later layer
to filter it out.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from ..schema import SchemaError, make_envelope

_IGNORED_TYPES = {"GSM", "CDMA", "LTE", "NR"}  # cell towers: out of scope


def _parse_int(v: str) -> int | None:
    v = (v or "").strip()
    if not v:
        return None
    try:
        return int(float(v))
    except ValueError:
        return None


def parse_wigle_csv(path: str | Path) -> dict[str, Any]:
    """
    Parse a WiGLE CSV export file and return a validated NEXUS envelope
    (dict with schema_version/source/observations). Raises SchemaError
    if the file doesn't look like a WiGLE export.
    """
    path = Path(path)
    if not path.exists():
        raise SchemaError(f"file not found: {path}")

    with path.open("r", encoding="utf-8", errors="replace", newline="") as f:
        first_line = f.readline()
        if not first_line.startswith("WigleWifi"):
            raise SchemaError(
                "file does not look like a WiGLE CSV export "
                "(expected first line to start with 'WigleWifi')"
            )
        reader = csv.DictReader(f)
        observations: list[dict] = []
        skipped = 0

        for row in reader:
            rtype = (row.get("Type") or "").strip().upper()
            if rtype in _IGNORED_TYPES:
                skipped += 1
                continue

            mac = (row.get("MAC") or "").strip()
            if not mac:
                skipped += 1
                continue

            name = (row.get("SSID") or "").strip() or None
            rssi = _parse_int(row.get("RSSI", ""))
            first_seen = (row.get("FirstSeen") or "").strip() or None

            if rtype == "BLE":
                observations.append({
                    "type": "ble_advertisement",
                    "address": mac,
                    "local_name": name,
                    "address_type": "unknown",
                    "rssi_dbm": rssi,
                    "last_seen": first_seen or "",
                    "source": "wigle_csv",
                })
            else:  # default: WIFI
                observations.append({
                    "type": "wifi_ap",
                    "bssid": mac,
                    "ssid": name,
                    "channel": _parse_int(row.get("Channel", "")),
                    "frequency_mhz": _parse_int(row.get("Frequency", "")),
                    "rssi_dbm": rssi,
                    "security": (row.get("AuthMode") or "").strip() or None,
                    "first_seen": first_seen,
                    "last_seen": first_seen or "",
                    "source": "wigle_csv",
                })

    envelope = make_envelope(
        source="wigle_csv",
        observations=observations,
        notes=(
            f"Parsed from {path.name}. {skipped} row(s) skipped "
            f"(non-WiFi/BLE type or missing MAC). "
            f"GPS fields discarded on import per NEXUS privacy policy."
        ),
    )
    return envelope

"""
Local-only SQLite store for NEXUS observations.

No network calls happen anywhere in this module. Everything lives under
~/.nexus/nexus.db by default. This is the whole "local-first" promise
from the spec, enforced in code rather than just in prose.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable, Optional

from .schema import now_iso, Event

DEFAULT_DB_PATH = Path.home() / ".nexus" / "nexus.db"

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS sessions (
    id          TEXT PRIMARY KEY,
    created_at  TEXT NOT NULL,
    source      TEXT NOT NULL,
    notes       TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS observations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL,
    obs_type    TEXT NOT NULL,
    key_field   TEXT NOT NULL,     -- bssid / address / ip, for dedupe & display
    last_seen   TEXT NOT NULL,
    data        TEXT NOT NULL,     -- full observation JSON
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT,
    event_type  TEXT NOT NULL,
    timestamp   TEXT NOT NULL,
    detail      TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_obs_type ON observations(obs_type);
CREATE INDEX IF NOT EXISTS idx_obs_session ON observations(session_id);
"""


class Store:
    def __init__(self, db_path: Path = DEFAULT_DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(_SCHEMA_SQL)
        self.conn.commit()

    # -- sessions ---------------------------------------------------

    def create_session(self, session_id: str, source: str, notes: str = "") -> None:
        self.conn.execute(
            "INSERT OR IGNORE INTO sessions (id, created_at, source, notes) VALUES (?,?,?,?)",
            (session_id, now_iso(), source, notes),
        )
        self.conn.commit()

    def list_sessions(self) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM sessions ORDER BY created_at DESC"
        ).fetchall()

    # -- observations -------------------------------------------------

    _KEY_FIELD = {"wifi_ap": "bssid", "ble_advertisement": "address", "lan_host": "ip"}

    def save_observations(self, session_id: str, observations: Iterable[dict]) -> int:
        n = 0
        for obs in observations:
            key_field = obs.get(self._KEY_FIELD.get(obs["type"], ""), "")
            last_seen = obs.get("last_seen") or obs.get("observed_at") or now_iso()
            self.conn.execute(
                "INSERT INTO observations (session_id, obs_type, key_field, last_seen, data) "
                "VALUES (?,?,?,?,?)",
                (session_id, obs["type"], str(key_field), last_seen, json.dumps(obs)),
            )
            n += 1
        self.conn.commit()
        return n

    def query_observations(self, obs_type: Optional[str] = None,
                            session_id: Optional[str] = None,
                            limit: int = 500) -> list[dict]:
        sql = "SELECT * FROM observations WHERE 1=1"
        params: list[Any] = []
        if obs_type:
            sql += " AND obs_type = ?"
            params.append(obs_type)
        if session_id:
            sql += " AND session_id = ?"
            params.append(session_id)
        sql += " ORDER BY last_seen DESC LIMIT ?"
        params.append(limit)
        rows = self.conn.execute(sql, params).fetchall()
        return [json.loads(r["data"]) | {"_session_id": r["session_id"]} for r in rows]

    def counts_by_type(self, session_id: Optional[str] = None) -> dict[str, int]:
        sql = "SELECT obs_type, COUNT(*) c FROM observations"
        params: list[Any] = []
        if session_id:
            sql += " WHERE session_id = ?"
            params.append(session_id)
        sql += " GROUP BY obs_type"
        return {r["obs_type"]: r["c"] for r in self.conn.execute(sql, params)}

    # -- events ---------------------------------------------------------

    def log_event(self, event: Event, session_id: Optional[str] = None) -> None:
        self.conn.execute(
            "INSERT INTO events (session_id, event_type, timestamp, detail) VALUES (?,?,?,?)",
            (session_id, event.event_type, event.timestamp, event.detail),
        )
        self.conn.commit()

    def recent_events(self, limit: int = 25) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM events ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()

    # -- deletion / export -----------------------------------------------

    def delete_session(self, session_id: str) -> None:
        self.conn.execute("DELETE FROM observations WHERE session_id = ?", (session_id,))
        self.conn.execute("DELETE FROM events WHERE session_id = ?", (session_id,))
        self.conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        self.conn.commit()

    def delete_all(self) -> None:
        self.conn.executescript(
            "DELETE FROM observations; DELETE FROM events; DELETE FROM sessions;"
        )
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

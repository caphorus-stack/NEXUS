"""
NEXUS terminal cyberdeck -- OVERVIEW / WI-FI / BLUETOOTH / LAN / HISTORY
panels, rendered phone-width-first.

Uses `rich` for the full palette (phosphor green / cyan / violet / amber
/ red per spec sec. 6) when it's installed. If it isn't, falls back to
plain ANSI so the dashboard still runs -- a missing pip package
shouldn't be a hard failure on a first-run phone.
"""

from __future__ import annotations

from typing import Optional

from .store import Store

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    _HAVE_RICH = True
except ImportError:
    _HAVE_RICH = False

GREEN = "bright_green"
CYAN = "cyan"
VIOLET = "magenta"
AMBER = "yellow"
RED = "red"

_ANSI = {GREEN: "\033[92m", CYAN: "\033[96m", VIOLET: "\033[95m",
         AMBER: "\033[93m", RED: "\033[91m", "reset": "\033[0m", "bold": "\033[1m"}


def _plain(text: str, color: str, bold: bool = False) -> str:
    c = _ANSI.get(color, "")
    b = _ANSI["bold"] if bold else ""
    return f"{b}{c}{text}{_ANSI['reset']}"


def _header(title: str) -> None:
    if _HAVE_RICH:
        Console().print(Panel(Text(title, style=f"bold {GREEN}"), border_style=CYAN))
    else:
        print(_plain(f"=== {title} ===", GREEN, bold=True))


def _age_note() -> str:
    return "data reflects last import, not a live radio feed"


def overview(store: Store, session_id: Optional[str] = None) -> None:
    _header("NEXUS CYBERDECK :: OVERVIEW")
    counts = store.counts_by_type(session_id)
    wifi_n = counts.get("wifi_ap", 0)
    ble_n = counts.get("ble_advertisement", 0)
    lan_n = counts.get("lan_host", 0)
    events = store.recent_events(limit=8)

    if _HAVE_RICH:
        console = Console()
        table = Table(show_header=True, header_style=f"bold {CYAN}")
        table.add_column("Category")
        table.add_column("Count", justify="right")
        table.add_row(Text("Wi-Fi APs", style=CYAN), str(wifi_n))
        table.add_row(Text("BLE advertisements", style=VIOLET), str(ble_n))
        table.add_row(Text("LAN responders", style=GREEN), str(lan_n))
        console.print(table)
        if not (wifi_n or ble_n or lan_n):
            console.print(Text(
                "No observations imported yet -- this means nothing has "
                "been imported, NOT that no devices exist nearby.",
                style=AMBER))
        console.print(Text(f"({_age_note()})", style="dim"))

        ev_table = Table(title="Recent events", header_style=f"bold {CYAN}")
        ev_table.add_column("Time")
        ev_table.add_column("Event")
        ev_table.add_column("Detail")
        for e in events:
            ev_table.add_row(e["timestamp"], e["event_type"], e["detail"])
        console.print(ev_table)
    else:
        print(f"  {_plain('Wi-Fi APs', CYAN)}: {wifi_n}")
        print(f"  {_plain('BLE advertisements', VIOLET)}: {ble_n}")
        print(f"  {_plain('LAN responders', GREEN)}: {lan_n}")
        if not (wifi_n or ble_n or lan_n):
            print(_plain(
                "  No observations imported yet -- this means nothing has "
                "been imported, NOT that no devices exist nearby.", AMBER))
        print(f"  ({_age_note()})")
        print("\n  Recent events:")
        for e in events:
            print(f"    [{e['timestamp']}] {e['event_type']}: {e['detail']}")


def wifi_field(store: Store, session_id: Optional[str] = None) -> None:
    _header("WI-FI FIELD")
    rows = store.query_observations("wifi_ap", session_id)
    if not rows:
        print(_plain("  No Wi-Fi observations imported.", AMBER))
        return
    if _HAVE_RICH:
        console = Console()
        table = Table(header_style=f"bold {CYAN}")
        for col in ("SSID", "BSSID", "Ch", "RSSI", "Security", "Last seen"):
            table.add_column(col)
        for r in rows:
            table.add_row(
                r.get("ssid") or "[hidden]", r.get("bssid", ""),
                str(r.get("channel") or "-"), str(r.get("rssi_dbm") or "-"),
                r.get("security") or "-", r.get("last_seen", ""),
            )
        console.print(table)
    else:
        for r in rows:
            print(f"  {r.get('ssid') or '[hidden]':20s} {r.get('bssid',''):18s} "
                  f"ch={r.get('channel','-')} rssi={r.get('rssi_dbm','-')} "
                  f"sec={r.get('security','-')}  seen={r.get('last_seen','')}")


def bluetooth_field(store: Store, session_id: Optional[str] = None) -> None:
    _header("BLUETOOTH FIELD")
    rows = store.query_observations("ble_advertisement", session_id)
    if not rows:
        print(_plain("  No BLE observations imported.", AMBER))
        return
    for r in rows:
        name = r.get("local_name") or "[no name advertised]"
        line = (f"  {name:24s} {r.get('address',''):18s} "
                f"rssi={r.get('rssi_dbm','-')}  seen={r.get('last_seen','')}")
        print(_plain(line, VIOLET) if not _HAVE_RICH else line)


def lan_watch_view(store: Store, session_id: Optional[str] = None) -> None:
    _header("LAN WATCH")
    rows = store.query_observations("lan_host", session_id)
    if not rows:
        print(_plain("  No LAN probe results. Run: nexus lan-watch --subnet <cidr> --confirm", AMBER))
        return
    for r in rows:
        print(f"  {r.get('ip',''):16s} responded to probe on port {r.get('port')}"
              f" (rtt {r.get('rtt_ms','-')} ms)")
    print(_plain("  Note: 'responded to probe' only -- not 'online', not 'has internet'.", AMBER))


def history_view(store: Store) -> None:
    _header("HISTORY :: SESSIONS")
    sessions = store.list_sessions()
    if not sessions:
        print(_plain("  No sessions yet.", AMBER))
        return
    for s in sessions:
        print(f"  {s['id']:24s} source={s['source']:12s} created={s['created_at']}  {s['notes']}")


def settings_view(store: Store) -> None:
    _header("SETTINGS")
    print(f"  Local database: {store.db_path}")
    print("  No scan data is transmitted off-device by default.")
    print("  Delete a session:  nexus history delete --session <id>")
    print("  Delete everything: nexus history delete --all")

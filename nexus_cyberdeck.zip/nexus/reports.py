"""
Report generation. Every report states its sources and limitations --
no unqualified "devices detected" counts, per spec sec. 4 and 10.
"""

from __future__ import annotations

from pathlib import Path

from .schema import now_iso
from .store import Store

DEFAULT_REPORT_DIR = Path.home() / "nexus_reports"

_LIMITATIONS = """
## Known limitations (read before interpreting counts)

- **Wi-Fi APs** are access points *seen broadcasting*, not every client connected to them.
- **BLE advertisements** are only devices that were actively advertising during the scan.
  Sleeping, non-advertising, randomized-address, or out-of-range devices will not appear.
- **LAN responders** reflect hosts that answered a specific TCP port probe. "No response"
  does not mean a host is offline -- it may simply not have that port open, or may be
  filtered by the router (client/AP isolation, firewall rules).
- None of these categories should be summed into a single "devices detected" number --
  they measure different things.
- This report was generated from **imported** data (see Source below), not a live scan.
"""


def generate_report(store: Store, session_id: str | None = None,
                     out_dir: Path = DEFAULT_REPORT_DIR) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    counts = store.counts_by_type(session_id)
    wifi = store.query_observations("wifi_ap", session_id)
    ble = store.query_observations("ble_advertisement", session_id)
    lan = store.query_observations("lan_host", session_id)

    ts = now_iso()
    lines = [
        f"# NEXUS Cyberdeck Report",
        f"",
        f"Generated: {ts}",
        f"Session filter: {session_id or 'ALL'}",
        f"",
        f"## Summary",
        f"",
        f"| Category | Count |",
        f"|---|---|",
        f"| Wi-Fi APs | {counts.get('wifi_ap', 0)} |",
        f"| BLE advertisements | {counts.get('ble_advertisement', 0)} |",
        f"| LAN responders | {counts.get('lan_host', 0)} |",
        _LIMITATIONS,
        f"## Wi-Fi APs",
        f"",
        f"| SSID | BSSID | Channel | RSSI | Security | Last seen |",
        f"|---|---|---|---|---|---|",
    ]
    for r in wifi:
        lines.append(
            f"| {r.get('ssid') or '[hidden]'} | {r.get('bssid','')} | "
            f"{r.get('channel','-')} | {r.get('rssi_dbm','-')} | "
            f"{r.get('security','-')} | {r.get('last_seen','')} |"
        )

    lines += ["", "## BLE advertisements", "",
              "| Name | Address | RSSI | Last seen |", "|---|---|---|---|"]
    for r in ble:
        lines.append(
            f"| {r.get('local_name') or '[none]'} | {r.get('address','')} | "
            f"{r.get('rssi_dbm','-')} | {r.get('last_seen','')} |"
        )

    lines += ["", "## LAN responders", "",
              "| IP | Port | RTT (ms) | Observed at |", "|---|---|---|---|"]
    for r in lan:
        lines.append(
            f"| {r.get('ip','')} | {r.get('port','-')} | "
            f"{r.get('rtt_ms','-')} | {r.get('observed_at','')} |"
        )

    lines += ["", "---", "No scan data in this report was transmitted off-device."]

    fname = f"nexus_report_{ts.replace(':', '-')}.md"
    out_path = out_dir / fname
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path

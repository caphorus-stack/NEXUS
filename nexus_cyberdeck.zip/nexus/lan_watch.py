"""
LAN Watch -- optional, authorised, bounded reachability checks.

Hard rules enforced in code, not just docs:
  - Caller MUST pass authorized=True. There is no flag that scans
    without it.
  - Subnet MUST be in RFC1918 / link-local private space. Public
    ranges are rejected outright -- NEXUS does not probe the internet.
  - Host count and probe rate are capped.
  - A host is reported as "responded to probe on port X", never as
    "online" or "has internet access". That distinction is load-bearing
    per the spec -- a TCP SYN/ACK tells you a port answered, nothing more.

No ICMP here: Horus/PRoot has no root and no raw-socket capability, so
a real ping would just fail silently or need setuid binaries that don't
exist in this environment. TCP connect-scan uses ordinary sockets and
works through Android's existing network stack without any special
privilege -- which also means it's the version of this that actually
runs without hiccups.
"""

from __future__ import annotations

import ipaddress
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterator

from .schema import now_iso

DEFAULT_PORTS = (80, 443, 22, 8080, 8443)
MAX_HOSTS = 254          # i.e. at most a /24
MAX_CONCURRENCY = 20
DEFAULT_TIMEOUT_S = 0.6


class LANWatchError(ValueError):
    pass


def _assert_private(network: ipaddress.IPv4Network) -> None:
    if not (network.is_private or network.is_link_local):
        raise LANWatchError(
            f"{network} is not a private/link-local range -- "
            "NEXUS LAN Watch only probes RFC1918/link-local subnets you've authorised."
        )


def _probe_host_port(ip: str, port: int, timeout: float) -> tuple[bool, float | None]:
    start = time.monotonic()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            result = s.connect_ex((ip, port))
            rtt_ms = (time.monotonic() - start) * 1000
            return (result == 0, rtt_ms)
    except OSError:
        return (False, None)


def scan_subnet(
    cidr: str,
    authorized: bool,
    ports: tuple[int, ...] = DEFAULT_PORTS,
    max_hosts: int = MAX_HOSTS,
    timeout: float = DEFAULT_TIMEOUT_S,
    concurrency: int = MAX_CONCURRENCY,
) -> Iterator[dict]:
    """
    Yield lan_host observations. One observation per host that
    responded on at least one probed port; non-responders are not
    yielded as observations (silence isn't "offline", it's just
    silence -- see spec sec. 4).
    """
    if not authorized:
        raise LANWatchError(
            "LAN Watch requires explicit authorisation. "
            "Re-run with authorized=True only on a subnet you have permission to probe."
        )

    network = ipaddress.ip_network(cidr, strict=False)
    if not isinstance(network, ipaddress.IPv4Network):
        raise LANWatchError("only IPv4 CIDR ranges are supported")
    _assert_private(network)

    hosts = list(network.hosts())
    if len(hosts) > max_hosts:
        raise LANWatchError(
            f"{cidr} has {len(hosts)} host addresses, over the cap of {max_hosts}. "
            "Narrow the range (e.g. a /24 or smaller)."
        )

    jobs = [(str(h), p) for h in hosts for p in ports]

    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        futures = {
            pool.submit(_probe_host_port, ip, port, timeout): (ip, port)
            for ip, port in jobs
        }
        seen_ips: set[str] = set()
        for fut in as_completed(futures):
            ip, port = futures[fut]
            responded, rtt_ms = fut.result()
            if responded and ip not in seen_ips:
                seen_ips.add(ip)
                yield {
                    "type": "lan_host",
                    "ip": ip,
                    "responded": True,
                    "probe_type": "tcp_port",
                    "port": port,
                    "rtt_ms": round(rtt_ms, 1) if rtt_ms is not None else None,
                    "observed_at": now_iso(),
                    "source": "lan_watch",
                }
